# kills all jobs
sudo pm2 delete all
