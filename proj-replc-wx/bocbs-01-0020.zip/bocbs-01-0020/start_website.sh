# Change the --name parameter for each release
sudo pm2 start index.js --name bocbs-01-0020
