console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log(' ');
console.log('####################################################');
console.log('##                                                ##');
console.log('##   BAMF created by BOC Business Solutions LLC   ##');
console.log('##                                                ##');
console.log('####################################################');
console.log('Starting BAMF services...');
console.log('Defining variable inputs for nodejs..');
var listenPort = 443;
var io   = require('socket.io'),
    url  = require('url'),
    express = require('express'),
    http = require('http');
var path = require('path')
var app = express();
var server = http.createServer(app);
var socket = io.listen(server);

console.log('Starting nodejs web server...');
app.use(express.static(path.join(__dirname, '/web')));
app.engine('.html', require('ejs').__express);
app.set('views', __dirname + '/web');
app.set('view engine', 'html');

app.get('/', function(req, res){
    res.render('home');
});

app.listen(listenPort);
console.log('Web service listening on port '+listenPort);
