

function testClickiness(){
    alert("Yay I just clicked a button and it did something!!");
}

function signUpForFree(){
	//testClickiness()
    var url = "https://join.slack.com/t/bocbs/shared_invite/enQtMzM3MTI1MjkyMDY1LWQ5NTkzMjY3ZTAyMzU2OGM1NmQzMjFlMjdhYzQ1MTU1NTk2YTNlNjU5YmI5NTJkNDg2YmNlY2IzMjg5MDg5Y2E";
	window.open(url,'_blank');
}

function signUpForBasic(){
	//testClickiness();
    var url = "signup.html#";
	window.location.href = url;
}

function signUpForCustom(){
	//testClickiness();
    var url = "signup.html#";
	window.location.href = url;
    
}


function startEngagement(){
   //testClickiness();
   var state = document.getElementById("state").value;
   //alert("You clicked "+state);
   sendMail(state);
}


function sendMail(a){
	var state = a;
	alert("Sending email: state selected "+state);

}