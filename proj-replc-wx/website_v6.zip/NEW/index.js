var io   = require('socket.io'),
    url  = require('url'),
    sys  = require('sys'),
    express = require('express'),
    http=require('http');
    var path = require('path')

var app = express();
var server = http.createServer(app);
var socket = io.listen(server);

app.use(express.static(path.join(__dirname, '/web')));
app.engine('.html', require('ejs').__express);
app.set('views', __dirname + '/web');
app.set('view engine', 'html');

app.get('/', function(req, res){
    res.render('home');
});

app.listen(3000);
sys.puts('server running ' + 'now ' + Date.now());
