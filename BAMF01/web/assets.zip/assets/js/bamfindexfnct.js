//Base javascript functions for index.html page

function testing123()
{
   alert("This works!");
}