

function alertHelloWorld() {
	alert("HELLO WORLD!!");
}


function writeToDB(fName, lName, sInt) {
	alert(fName+" "+lName+" "+sInt);

  var mysql = require('mysql');

  var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "VMware1!",
  database: "world"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  var sql = "INSERT INTO `world`.`labtwo` (`ID`,`firstName`,`lastName`,`somethingInteresting`) VALUES (5,'Brendan', 'OConnor', 'yay NODEJS')";

  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
  });
});
    
    alert("executed");

}


function loadDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("demo").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", "sample.txt", true);
  xhttp.send();
}


