
var args = ["Hello", "My", "Name", "is", "Brendan"];
var paramlen = args.length;
console.log("There are "+paramlen+" parameters");

for (var i = 0; i < paramlen; i++) {
  console.log("Param "+i+": "+args[i]);
  }
