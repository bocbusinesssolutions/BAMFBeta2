var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "VMware1!",
  database: "world"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  var sql = "INSERT INTO `world`.`labtwo` (`ID`,`firstName`,`lastName`,`somethingInteresting`) VALUES (4,'Brendan', 'OConnor', 'yay AJAX')";

  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
  });
});